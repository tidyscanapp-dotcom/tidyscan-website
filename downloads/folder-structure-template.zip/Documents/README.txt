﻿Folder structure for household documents

Ten folders, two levels at most. Anything unclear goes into 00_Inbox.
Guide: https://tidyscan.org/folder-structure-template/

Template: TidyScan (tidyscan.org), licence CC BY 4.0
https://creativecommons.org/licenses/by/4.0/
Free to use, adapt and share, with the credit «TidyScan, tidyscan.org».
